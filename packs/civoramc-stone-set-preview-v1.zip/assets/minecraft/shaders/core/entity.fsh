#version 330
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
uniform sampler2D Sampler0;
#ifdef DISSOLVE
uniform sampler2D DissolveMaskSampler;
#endif
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
in vec4 vertexPerFaceColorBack;
in vec4 vertexPerFaceColorFront;
#else
in vec4 vertexColor;
#endif
#ifndef EMISSIVE
in vec4 lightMapColor;
#endif
#ifndef NO_OVERLAY
in vec4 overlayColor;
#endif
in vec2 texCoord0;
out vec4 fragColor;
#if defined(PER_FACE_LIGHTING) || !defined(NO_CARDINAL_LIGHTING)
#moj_import <minecraft:light.glsl>
#endif
#moj_import <minecraft:projection.glsl>
in vec4 cbCorner0;
in vec4 cbCorner2;
flat in vec3 cbNormal;
in vec3 cbRay;
flat in int cbActive;
#moj_import <civoramc:backpack_boxes.glsl>
bool cbIntersect(vec3 ro, vec3 rd, vec3 lo, vec3 hi, out float distance, out vec3 normal) {
vec3 direction = mix(vec3(0.000001), vec3(-0.000001), lessThan(rd, vec3(0.0)));
direction = mix(direction, rd, greaterThan(abs(rd), vec3(0.000001)));
vec3 first = (lo - ro) / direction;
vec3 second = (hi - ro) / direction;
vec3 nearPlane = min(first, second);
vec3 farPlane = max(first, second);
float nearT = max(max(nearPlane.x, nearPlane.y), nearPlane.z);
float farT = min(min(farPlane.x, farPlane.y), farPlane.z);
if (nearT > farT || farT < 0.0) return false;
bool outside = nearT >= 0.0;
distance = outside ? nearT : farT;
vec3 planes = outside ? nearPlane : farPlane;
normal = vec3(0.0);
if (outside) {
if (planes.x >= planes.y && planes.x >= planes.z) normal.x = -sign(direction.x);
else if (planes.y >= planes.z) normal.y = -sign(direction.y);
else normal.z = -sign(direction.z);
} else {
if (planes.x <= planes.y && planes.x <= planes.z) normal.x = sign(direction.x);
else if (planes.y <= planes.z) normal.y = sign(direction.y);
else normal.z = sign(direction.z);
}
return true;
}
bool cbShade(out vec4 color, out vec3 viewHit) {
if (cbCorner0.w <= 0.0000001 || cbCorner2.w <= 0.0000001) return false;
vec3 p0 = cbCorner0.xyz / cbCorner0.w;
vec3 p2 = cbCorner2.xyz / cbCorner2.w;
vec3 diagonal = p0 - p2;
vec3 outward = normalize(cbNormal);
vec3 perpendicular = cross(outward, diagonal);
vec3 right = normalize(10.0 * diagonal - 14.0 * perpendicular);
vec3 up = normalize(14.0 * diagonal + 10.0 * perpendicular);
mat3 frame = mat3(right, up, outward);
float unit = length(diagonal) / sqrt(296.0);
vec3 center = (p0 + p2) * 0.5;
vec3 ray = normalize(cbRay);
vec3 ro = (-center * frame) / unit;
vec3 rd = (ray * frame) / unit;
float nearest;
vec3 hitNormal;
if (!cbIntersect(ro, rd, CB_BOUND_MIN, CB_BOUND_MAX, nearest, hitNormal)) return false;
nearest = 1000000.0;
int material = -1;
for (int i = 0; i < CB_BOX_COUNT; ++i) {
float distance;
vec3 normal;
if (cbIntersect(ro, rd, CB_MIN[i], CB_MAX[i], distance, normal) && distance < nearest) {
nearest = distance;
hitNormal = normal;
material = CB_MATERIAL[i];
}
}
if (material < 0) return false;
vec3 hit = ro + rd * nearest;
vec2 uv;
if (abs(hitNormal.x) > 0.5) uv = hit.zy;
else if (abs(hitNormal.y) > 0.5) uv = hit.xz;
else uv = hit.xy;
ivec2 texel = ivec2(material * 8 + int(mod(floor(uv.x * 2.0), 8.0)), int(mod(floor(uv.y * 2.0), 16.0)));
color = texelFetch(Sampler0, texel, 0);
#if defined(PER_FACE_LIGHTING) || !defined(NO_CARDINAL_LIGHTING)
vec3 originalNormal = normalize(inverse(mat3(ModelViewMat)) * (frame * hitNormal));
color = minecraft_mix_light(Light0_Direction, Light1_Direction, originalNormal, color);
#endif
viewHit = ray * nearest;
return true;
}
void main() {
gl_FragDepth = gl_FragCoord.z;
if (cbActive != 0) {
vec4 packColor;
vec3 hitPosition;
if (!cbShade(packColor, hitPosition)) discard;
#ifdef PER_FACE_LIGHTING
packColor.a *= vertexPerFaceColorFront.a;
#else
packColor.a *= vertexColor.a;
#endif
packColor *= ColorModulator;
#ifdef ALPHA_CUTOUT
if (packColor.a < ALPHA_CUTOUT) discard;
#endif
#ifdef DISSOLVE
if (packColor.a < texture(DissolveMaskSampler, texCoord0).a) discard;
packColor.a = 1.0;
#endif
#ifndef NO_OVERLAY
packColor.rgb = mix(overlayColor.rgb, packColor.rgb, overlayColor.a);
#endif
#ifndef EMISSIVE
packColor *= lightMapColor;
#endif
vec4 clip = ProjMat * vec4(hitPosition, 1.0);
vec4 proxyClip = ProjMat * vec4(cbRay, 1.0);
float proxyNdc = proxyClip.z / proxyClip.w;
float scale = abs(gl_FragCoord.z - proxyNdc)
< abs(gl_FragCoord.z - (proxyNdc * 0.5 + 0.5)) ? 1.0 : 0.5;
float depth = gl_FragCoord.z + (clip.z / clip.w - proxyNdc) * scale;
if (depth < 0.0 || depth > 1.0) discard;
gl_FragDepth = depth;
vec3 originalHit = (inverse(ModelViewMat) * vec4(hitPosition, 1.0)).xyz;
fragColor = apply_fog(packColor, length(originalHit), max(length(originalHit.xz), abs(originalHit.y)),
FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
return;
}
vec4 color = texture(Sampler0, texCoord0);
#ifdef ALPHA_CUTOUT
if (color.a < ALPHA_CUTOUT) {
discard;
}
#endif
#ifdef PER_FACE_LIGHTING
vec4 faceVertexColor = gl_FrontFacing ? vertexPerFaceColorFront : vertexPerFaceColorBack;
#else
vec4 faceVertexColor = vertexColor;
#endif
#ifdef DISSOLVE
if (faceVertexColor.a < texture(DissolveMaskSampler, texCoord0).a) {
discard;
}
faceVertexColor.a = 1.0;
#endif
color *= faceVertexColor * ColorModulator;
#ifndef NO_OVERLAY
color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
#endif
#ifndef EMISSIVE
color *= lightMapColor;
#endif
fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
