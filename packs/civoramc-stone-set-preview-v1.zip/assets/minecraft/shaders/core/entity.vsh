#version 330
#if defined(PER_FACE_LIGHTING) || !defined(NO_CARDINAL_LIGHTING)
#moj_import <minecraft:light.glsl>
#endif
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;
#ifndef NO_OVERLAY
uniform sampler2D Sampler1;
#endif
#ifndef EMISSIVE
uniform sampler2D Sampler2;
#endif
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
out vec4 vertexPerFaceColorBack;
out vec4 vertexPerFaceColorFront;
#else
out vec4 vertexColor;
#endif
#ifndef EMISSIVE
out vec4 lightMapColor;
#endif
#ifndef NO_OVERLAY
out vec4 overlayColor;
#endif
out vec2 texCoord0;
uniform sampler2D Sampler0;
out vec4 cbCorner0;
out vec4 cbCorner2;
flat out vec3 cbNormal;
out vec3 cbRay;
flat out int cbActive;
void main() {
gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
sphericalVertexDistance = fog_spherical_distance(Position);
cylindricalVertexDistance = fog_cylindrical_distance(Position);
#ifdef PER_FACE_LIGHTING
vec2 light = minecraft_compute_light(Light0_Direction, Light1_Direction, Normal);
vertexPerFaceColorBack = minecraft_mix_light_separate(-light, Color);
vertexPerFaceColorFront = minecraft_mix_light_separate(light, Color);
#elif defined(NO_CARDINAL_LIGHTING)
vertexColor = Color;
#else
vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
#endif
#ifndef EMISSIVE
lightMapColor = sample_lightmap(Sampler2, UV2);
#endif
#ifndef NO_OVERLAY
overlayColor = texelFetch(Sampler1, UV1, 0);
#endif
texCoord0 = UV0;
#ifdef APPLY_TEXTURE_MATRIX
texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
#endif
cbCorner0 = vec4(0.0);
cbCorner2 = vec4(0.0);
cbNormal = vec3(0.0);
cbRay = vec3(0.0);
cbActive = 0;
if (textureSize(Sampler0, 0) == ivec2(64, 32)) {
ivec4 tag = ivec4(round(texelFetch(Sampler0, ivec2(63,31), 0) * 255.0));
bool plainPack = all(equal(tag, ivec4(19,53,91,255)));
bool signalledPack = all(equal(tag, ivec4(19,53,92,255)));
if (!plainPack && !signalledPack) return;
cbActive = 1;
if (signalledPack && any(notEqual(ivec3(round(Color.rgb * 255.0)), ivec3(19,53,91)))) {
gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
return;
}
const vec2 backUV[4] = vec2[4](vec2(40,20), vec2(32,20), vec2(32,32), vec2(40,32));
int cornerIndex = -1;
for (int i = 0; i < 4; ++i) {
if (all(lessThan(abs(UV0 * vec2(64,32) - backUV[i]), vec2(0.01)))) cornerIndex = i;
}
if (cornerIndex >= 0) {
vec4 viewPosition = ModelViewMat * vec4(Position, 1.0);
if (cornerIndex == 0) cbCorner0 = viewPosition;
if (cornerIndex == 2) cbCorner2 = viewPosition;
cbNormal = normalize(transpose(inverse(mat3(ModelViewMat))) * Normal);
const vec2 screenCorners[4] = vec2[4](vec2(-1, 1), vec2(1, 1), vec2(1, -1), vec2(-1, -1));
viewPosition.xy += screenCorners[cornerIndex] * 1.25;
viewPosition.z = min(viewPosition.z, -0.05);
cbRay = viewPosition.xyz;
gl_Position = ProjMat * viewPosition;
} else {
gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
}
}
}
